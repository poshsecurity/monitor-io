/*
 *  LCD Write Utility
 */
#define MAX_LCD_TEXT	16

typedef enum {
	LCD_COLOR_NONE,
	LCD_COLOR_RED,
	LCD_COLOR_GREEN,
	LCD_COLOR_BLUE,
	LCD_COLOR_YELLOW,
	LCD_COLOR_CYAN,
	LCD_COLOR_MAGENTA,
	LCD_COLOR_WHITE
} LCDColor;

typedef enum {
	GPIO_RASPBERRY_PI,
	GPIO_ORANGE_PI,
	GPIO_ORANGE_PI_ONEPLUS
} LCDType;

typedef enum {
	LCD_LINE1,
	LCD_LINE2
} LCDLineNum;

bool initLCD( LCDType, LCDColor );
void writeLCDText( LCDLineNum, char*, bool );
bool setLCDColor( LCDColor );
