/*
 *  LCD Write Utility
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <unistd.h>
#include <stdbool.h>
#include <string.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <limits.h>
#include <time.h>
#include <fcntl.h>

#include "lcd.h"
#include "lcdwrite.h"

bool get_hardware_info( void );
HardwareType hwtype = HW_UNKNOWN;

#define SCRATCHSIZE 1024
char scratch[ SCRATCHSIZE ];

//----------------------------------------------------------------------------
bool get_hardware_info() {
	FILE *fp;
	char *line = scratch, *hw;

	*line = '\0';
	if ( ( fp = fopen("/proc/cpuinfo", "r") ) == NULL )
		return(false);

	hwtype = HW_ORANGE_PI_ONEPLUS;
	while ( fgets(line, SCRATCHSIZE, fp) ) {
		if ( !strncmp(line, "Hardware", 8) ) {
			if ( ( hw = strchr(line, ':') ) != NULL ) {
				hw += 2;
				if ( strstr(hw, "BCM") ) {
					hwtype = HW_RASPBERRY_PI;
				} else if ( strstr(hw, "sun8i") ) {
					hwtype = HW_ORANGE_PI;
				}
			}
			break;
		}
	}
	fclose(fp);
	return(true);
}
//----------------------------------------------------------------------------
int main( int argc, char** argv ) {
	int		opt, lcdColor = -1;
	bool		center = false;
	char		*line1 = NULL, *line2 = NULL;

	//
	// Process command line arguments
	//
	while ( ( opt = getopt(argc, argv, "fc:1:2:?") ) != -1 ) {
		switch (opt) {
		case 'f':
			center = true;
			break;
		case 'c':
			if ( *optarg == '0' )
				lcdColor = LCD_COLOR_NONE;
			else if ( *optarg == 'r' )
				lcdColor = LCD_COLOR_RED;
			else if ( *optarg == 'g' )
				lcdColor = LCD_COLOR_GREEN;
			else if ( *optarg == 'b' )
				lcdColor = LCD_COLOR_BLUE;
			else if ( *optarg == 'y' )
				lcdColor = LCD_COLOR_YELLOW;
			else if ( *optarg == 'c' )
				lcdColor = LCD_COLOR_CYAN;
			else if ( *optarg == 'm' )
				lcdColor = LCD_COLOR_MAGENTA;
			else if ( *optarg == 'w' )
				lcdColor = LCD_COLOR_WHITE;
			break;
		case '1':
			line1 = optarg;
			break;
		case '2':
			line2 = optarg;
			break;
		case '?':
		default:
			printf("Expecting: [-f] [-c <0|r|g|b|y|c|m|w>] [-1 \"<line1>\"] [-2 \"<line2>\"]\n");
			exit( 0 );
		}
	}
	if ( lcdColor == -1 && !line1 && !line2 )
		exit( 0 );

	//
	// Get hardware info
	//
	get_hardware_info();
	if ( hwtype == HW_RASPBERRY_PI ) {
		initLCD( GPIO_RASPBERRY_PI, lcdColor );
	} else if ( hwtype == HW_ORANGE_PI ) {
		initLCD( GPIO_ORANGE_PI, lcdColor );
	} else if ( hwtype == HW_ORANGE_PI_ONEPLUS ) {
		initLCD( GPIO_ORANGE_PI_ONEPLUS, lcdColor );
	} else {
		printf("Hardware Type: <Unknown>\n");
		exit( 1 );
	}

	//
	// Process based on parameters
	//
	if ( lcdColor != -1 ) {
		setLCDColor( lcdColor );
	}
	if ( line1 != NULL ) {
		writeLCDText( LCD_LINE1, line1, center );
	}
	if ( line2 != NULL ) {
		writeLCDText( LCD_LINE2, line2, center );
	}
	exit( 0 );
}
//----------------------------------------------------------------------------
