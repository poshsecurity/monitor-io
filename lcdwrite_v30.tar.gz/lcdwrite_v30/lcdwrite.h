/*
 *  LCD Write Utility
 */

typedef enum {
	HW_UNKNOWN,
	HW_RASPBERRY_PI,
	HW_ORANGE_PI,
	HW_ORANGE_PI_ONEPLUS
} HardwareType;

