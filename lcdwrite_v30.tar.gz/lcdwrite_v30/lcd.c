/*
 *  LCD Write Utility
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>
#include <sys/time.h>
#include <limits.h>
#include <string.h>
#include "gpio.h"
#include "lcd.h"

void pulseEnable( void );
void LCDByte( char );
void setCmdMode( void );
void setChrMode( void );
void setGPIOPin( int );

//
// On/Off settings for common anode/common cathode LEDs
//
#define LED_ON	GPIO_LOW
#define LED_OFF	GPIO_HIGH

//
// GPIO values for sysfs
//
int LCD_RS = 0;
int LCD_E = 0;
int LCD_D0 = 0;
int LCD_D1 = 0;
int LCD_D2 = 0;
int LCD_D3 = 0;
int LCD_D4 = 0;
int LCD_D5 = 0;
int LCD_D6 = 0;
int LCD_D7 = 0;
int LCD_RED = 0;
int LCD_GREEN = 0;
int LCD_BLUE = 0;

void pulseEnable( void ) {
	GPIOWrite( LCD_E, GPIO_HIGH ); 
	// Insert 1 microsecond pause (enable pulse must be > 450ns)
	usleep( 1 );
	GPIOWrite( LCD_E, GPIO_LOW ); 
}

//
// Send a byte to the lcd
// Before calling, use SetChrMode or SetCmdMode to send character or command
//
void LCDByte( char bits ) {
	GPIOWrite( LCD_D0, (bits & 0x1) );  
	GPIOWrite( LCD_D1, (bits & 0x2) );  
	GPIOWrite( LCD_D2, (bits & 0x4) );  
	GPIOWrite( LCD_D3, (bits & 0x8) );  
	GPIOWrite( LCD_D4, (bits & 0x10) );  
	GPIOWrite( LCD_D5, (bits & 0x20) );  
	GPIOWrite( LCD_D6, (bits & 0x40) );  
	GPIOWrite( LCD_D7, (bits & 0x80) );  
	pulseEnable();
}

void setCmdMode() {
	GPIOWrite( LCD_RS, GPIO_LOW );
}

void setChrMode() {
	GPIOWrite( LCD_RS, GPIO_HIGH );
}

void setGPIOPin( int gpio ) {
	GPIOExport( gpio );
	GPIODirection( gpio, GPIO_OUT );
}

bool initLCD( LCDType type, LCDColor lcdColor ) {
	//
	// Set GPIO values based on type
	//
	if ( type == GPIO_RASPBERRY_PI ) {
		LCD_RS = 24;
		LCD_E = 25;
		LCD_D0 = 5;
		LCD_D1 = 6;
		LCD_D2 = 13;
		LCD_D3 = 19;
		LCD_D4 = 26;
		LCD_D5 = 16;
		LCD_D6 = 20;
		LCD_D7 = 21;
		LCD_RED = 22;
		LCD_GREEN = 27;
		LCD_BLUE = 17;
	} else if ( type == GPIO_ORANGE_PI ) {
		LCD_RS = 71;
		LCD_E = 2;
		LCD_D0 = 7;
		LCD_D1 = 8;
		LCD_D2 = 9;
		LCD_D3 = 10;
		LCD_D4 = 20;
		LCD_D5 = 201;
		LCD_D6 = 198;
		LCD_D7 = 199;
		LCD_RED = 3;
		LCD_GREEN = 0;
		LCD_BLUE = 1;
	} else if ( type == GPIO_ORANGE_PI_ONEPLUS) {
		LCD_RS = 71;
		LCD_E = 121;
		LCD_D0 = 69;
		LCD_D1 = 227;
		LCD_D2 = 117;
		LCD_D3 = 118;
		LCD_D4 = 73;
		LCD_D5 = 120;
		LCD_D6 = 119;
		LCD_D7 = 122;
		LCD_RED = 230;
		LCD_GREEN = 229;
		LCD_BLUE = 228;
	} else {
		return( false );
	}

	//
	// Setup GPIO pins
	//
	setGPIOPin( LCD_RS );
	setGPIOPin( LCD_E );
	setGPIOPin( LCD_D0 );
	setGPIOPin( LCD_D1 );
	setGPIOPin( LCD_D2 );
	setGPIOPin( LCD_D3 );
	setGPIOPin( LCD_D4 );
	setGPIOPin( LCD_D5 );
	setGPIOPin( LCD_D6 );
	setGPIOPin( LCD_D7 );
	if ( lcdColor != -1 ) {	// Avoid flicker when not used
		setGPIOPin( LCD_RED );
		setGPIOPin( LCD_GREEN );
		setGPIOPin( LCD_BLUE );
	}

	//
	// Initialise LCD
	//
	setCmdMode();
	LCDByte( 0x38 );	// Mode 8-bit, 2 line, 5x8 dots
	usleep( 5000 );
	LCDByte( 0x38 );	// Mode 8-bit, 2 line, 5x8 dots
	usleep( 200 );
	LCDByte( 0x38 );	// Mode 8-bit, 2 line, 5x8 dots
	usleep( 200 );
	LCDByte( 0x0C );	// Display on, cursor off, blink off
	usleep( 200 );
	LCDByte( 0x01 );	// Display clear
	usleep( 3000 );
	LCDByte( 0x06 );	// Entry mode set

	return( true );
}

void writeLCDText( LCDLineNum linenum, char *s, bool center ) {
	int i, indent = 0;

	if ( s == NULL )
		return;

	setCmdMode();
	if ( linenum == LCD_LINE1 ) {
		LCDByte( 0x80 );	// Line 1
	} else {
		LCDByte( 0xC0 );	// Line 2
	}

	setChrMode();
	if ( center ) {
		i = ( MAX_LCD_TEXT - strlen( s ) ) / 2;
		if ( i > 0 && i < MAX_LCD_TEXT ) 
			indent = i;
	}
	for ( i = 0; i < MAX_LCD_TEXT; i++ ) {
		if ( indent-- > 0 ) {
			LCDByte( ' ' );
		} else if ( *s == '\0' ) {
			LCDByte( ' ' );
		} else {
			LCDByte( *s++ );
		}
	}
}

bool setLCDColor( LCDColor color ) {
	//
	// Perform basic color selection and mixing
	//
	switch ( color ) {
	case LCD_COLOR_NONE:
		GPIOWrite( LCD_RED, LED_OFF ); 
		GPIOWrite( LCD_GREEN, LED_OFF ); 
		GPIOWrite( LCD_BLUE, LED_OFF ); 
		break;
	case LCD_COLOR_RED:
		GPIOWrite( LCD_RED, LED_ON ); 
		GPIOWrite( LCD_GREEN, LED_OFF ); 
		GPIOWrite( LCD_BLUE, LED_OFF ); 
		break;
	case LCD_COLOR_GREEN:
		GPIOWrite( LCD_RED, LED_OFF ); 
		GPIOWrite( LCD_GREEN, LED_ON ); 
		GPIOWrite( LCD_BLUE, LED_OFF ); 
		break;
	case LCD_COLOR_BLUE:
		GPIOWrite( LCD_RED, LED_OFF ); 
		GPIOWrite( LCD_GREEN, LED_OFF ); 
		GPIOWrite( LCD_BLUE, LED_ON ); 
		break;
	case LCD_COLOR_YELLOW:
		GPIOWrite( LCD_RED, LED_ON ); 
		GPIOWrite( LCD_GREEN, LED_ON ); 
		GPIOWrite( LCD_BLUE, LED_OFF ); 
		break;
	case LCD_COLOR_CYAN:
		GPIOWrite( LCD_RED, LED_OFF ); 
		GPIOWrite( LCD_GREEN, LED_ON ); 
		GPIOWrite( LCD_BLUE, LED_ON ); 
		break;
	case LCD_COLOR_MAGENTA:
		GPIOWrite( LCD_RED, LED_ON ); 
		GPIOWrite( LCD_GREEN, LED_OFF ); 
		GPIOWrite( LCD_BLUE, LED_ON ); 
		break;
	case LCD_COLOR_WHITE:
		GPIOWrite( LCD_RED, LED_ON ); 
		GPIOWrite( LCD_GREEN, LED_ON ); 
		GPIOWrite( LCD_BLUE, LED_ON ); 
		break;
	default:
		return( false );
	}

	return( true );
}
