/*
 *  LCD Write Utility
 */
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "gpio.h"

#define BUFFER_MAX 8
#define PATH_MAX 64

/*
 * @brief Error level logging macro.
 *
 * Macro to expose function, line number as well as desired log message.
 */
#ifdef ENABLE_IOT_ERROR
#define IOT_ERROR(...)  \
	{ \
	printf("ERROR: %s L#%d ", __func__, __LINE__); \
	printf(__VA_ARGS__); \
	printf("\n"); \
	}
#else
#define IOT_ERROR(...)
#endif

int GPIOExport(int pin) {
	char buffer[BUFFER_MAX];
	int fd, size;

	if ( ( fd = open("/sys/class/gpio/export", O_WRONLY) ) == -1 ) {
		IOT_ERROR("Failed to open export for writing %d", pin);
		return(-1);
	}
	size = snprintf(buffer, BUFFER_MAX, "%d", pin);
	write(fd, buffer, size);
	close(fd);
	return(0);
}

int GPIOUnexport(int pin) {
	char buffer[BUFFER_MAX];
	int fd, size;

	if ( ( fd = open("/sys/class/gpio/unexport", O_WRONLY) ) == -1 ) {
		IOT_ERROR("Failed to open unexport for writing %d", pin);
		return(-1);
	}
	size = snprintf(buffer, BUFFER_MAX, "%d", pin);
	write(fd, buffer, size);
	close(fd);
	return(0);
}

int GPIODirection(int pin, int dir) {
	char path[PATH_MAX];
	int fd, rc = -1;

	snprintf(path, PATH_MAX, "/sys/class/gpio/gpio%d/direction", pin);
	if ( ( fd = open(path, O_WRONLY) ) == -1 ) {
		IOT_ERROR("Failed to open gpio direction for writing %d", pin);
		return(-1);
	}
	if ( dir == GPIO_IN ) {
		rc = write(fd, "in", 2);
	} else if ( dir == GPIO_OUT ) {
		rc = write(fd, "out", 3);
	}
	close(fd);
	if ( rc == -1 ) {
		IOT_ERROR("Failed to set direction to %d for %d", dir, pin);
		return(-1);
	}
	return(0);
}

int GPIORead(int pin) {
	char path[PATH_MAX];
	char buffer[BUFFER_MAX];
	int fd, rc = -1;

	snprintf(path, PATH_MAX, "/sys/class/gpio/gpio%d/value", pin);
	if ( ( fd = open(path, O_RDONLY) ) == -1 ) {
		IOT_ERROR("Failed to open gpio value for reading %d", pin);
		return(-1);
	}
	rc = read(fd, buffer, BUFFER_MAX);
	close(fd);
	if ( rc == -1 ) {
		IOT_ERROR("Failed to read value from %d", pin);
		return(-1);
	}
	return( atoi( buffer ) );
}

int GPIOWrite(int pin, int value) {
	char path[PATH_MAX];
	int fd, rc = -1;

	snprintf(path, PATH_MAX, "/sys/class/gpio/gpio%d/value", pin);
	if ( ( fd = open(path, O_WRONLY) ) == -1 ) {
		IOT_ERROR("Failed to open gpio value for writing %d", pin);
		return(-1);
	}
	if ( value == 0 ) {
		rc = write(fd, "0", 1);
	} else {
		rc = write(fd, "1", 1);
	}
	close(fd);
	if ( rc != 1 ) {
		IOT_ERROR("Failed to write value to %d (%d)", pin, value);
		return(-1);
	}
	return(0);
}
